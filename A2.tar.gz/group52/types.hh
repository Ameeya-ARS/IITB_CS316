#include<iostream>
#include<string>
using namespace std;

class type_size{
    public:
        string type;
        int size;
        type_size();
        type_size(string c1,int c2);
};

class val_size{
    public:
        string val;
        int size;
        val_size();
        val_size(string c1,int c2);
};

string find_pointer_type(string type);
string array_to_pointer(string type);