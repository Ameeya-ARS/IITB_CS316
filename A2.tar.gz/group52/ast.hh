#include<iostream>
#include<vector>
using namespace std;

enum typeExp{EMPTY,SEQ,ASSIGNS,RETURN,IF,WHILE,FOR,PROCCALL,IDENTIFIER,ARRAYREF,MEMBER,ARROW,OP_BINARY,OP_UNARY_PP,OP_UNARY_DEREF,OP_UNARY_ADDRESS,OP_UNARY_UMINUS,OP_UNARY_NOT,ASSIGNE,FUNCALL,INTCONST,INTCONST0,FLOATCONST,FLOATCONST0,STRINGCONST};

class abstract_astnode{
    public :
        virtual void print(int blank)=0;
        enum typeExp astnode_type;
};

class statement_astnode : public abstract_astnode{
    public :
        void print(int blank){}
};

class exp_astnode : public abstract_astnode{
    public :
        string type;
        void print(int blank){}
};

class ref_astnode : public exp_astnode{
    public :
        void print(int blank){}
};

class empty_astnode : public statement_astnode{
    public :
        void print(int blank);
};

class seq_astnode : public statement_astnode{
    public :
        vector<statement_astnode*> child1;
        seq_astnode();
        seq_astnode(statement_astnode* c1);
        void add(statement_astnode* c1);

        void print(int blank);
};

class assignS_astnode : public statement_astnode
{
    public :
        exp_astnode *child1;
        exp_astnode *child2;
    
        assignS_astnode(exp_astnode *c1, exp_astnode *c2);

        void print(int blank);
};

class return_astnode : public statement_astnode{
    public :
        exp_astnode *child1;
    
        return_astnode(exp_astnode *c1);
        void print(int blank);
};

class proccall_astnode : public statement_astnode{
    public :
        vector<exp_astnode*>* child1;
    
        proccall_astnode(vector<exp_astnode*>* c1);
        void print(int blank);
};

class if_astnode : public statement_astnode{
    public :
        exp_astnode *child1;
        statement_astnode *child2;
        statement_astnode *child3;
    
        if_astnode(exp_astnode *c1, statement_astnode *c2, statement_astnode *c3);
        void print(int blank);
};

class while_astnode : public statement_astnode{
    public:
        exp_astnode *child1;
        statement_astnode *child2;
    
        while_astnode(exp_astnode *c1, statement_astnode *c2);
        void print(int blank);
};

class for_astnode : public statement_astnode{
    public :
        exp_astnode *child1;
        exp_astnode *child2;
        exp_astnode *child3;
        statement_astnode *child4;
    
        for_astnode(exp_astnode *c1,exp_astnode *c2,exp_astnode *c3,statement_astnode *c4);
        void print(int blank);
};

class op_binary_astnode : public exp_astnode{
    public :
        string child1;
        exp_astnode *child2;
        exp_astnode *child3;
    
        op_binary_astnode(string c1, exp_astnode *c2, exp_astnode *c3);
        void print(int blank);
};

class op_unary_astnode : public exp_astnode{
    public :
        string child1;
        exp_astnode *child2;
    
        op_unary_astnode(string c1, exp_astnode *c2);
        void print(int blank);
};

class assignE_astnode : public exp_astnode{
    public :
        exp_astnode *child1;
        exp_astnode *child2;
    
        assignE_astnode(exp_astnode *c1, exp_astnode *c2);
        void print(int blank);
};

class funcall_astnode : public exp_astnode{
    public :
        vector<exp_astnode*>* child1;
    
        funcall_astnode(vector<exp_astnode*>* c1);
        void print(int blank);
};

class floatconst_astnode : public exp_astnode{
    public :
        float child1;
    
        floatconst_astnode(float c1);
        void print(int blank);
};

class intconst_astnode : public exp_astnode{
    public :
        int child1;
    
        intconst_astnode(int c1);
        void print(int blank);
};

class string_astnode : public exp_astnode{
    public :
        string child1;
    
        string_astnode(string c1);
        void print(int blank);
};

class identifier_astnode : public ref_astnode{
    public:
        string child1;
    
        identifier_astnode(string c1);
        void print(int blank);
};

class member_astnode : public ref_astnode{
    public:
        exp_astnode *child1;
        identifier_astnode *child2;
    
        member_astnode(exp_astnode *c1, identifier_astnode *c2);
        void print(int blank);
};

class arrow_astnode : public ref_astnode{
    public :
        exp_astnode *child1;
        identifier_astnode *child2;
    
        arrow_astnode(exp_astnode *c1, identifier_astnode *c2);
        void print(int blank);
};

class arrayref_astnode : public ref_astnode{
    public :
        exp_astnode *child1;
        exp_astnode *child2;
    public :
        arrayref_astnode(exp_astnode *c1, exp_astnode *c2);
        void print(int blank);
};