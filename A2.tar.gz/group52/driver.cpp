#include <cstring>
#include <cstddef>
#include <istream>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>

#include "scanner.hh"
#include "parser.tab.hh"
extern map<string,localsymbtab*> list_func;
extern map<string,localsymbtab*> list_struct;
extern map<string,abstract_astnode*> ast;
extern globalsymbtab gst;
std::map<std::string, std::string> predefined {
            {"printf", "void"},
            {"scanf", "void"},
            {"mod", "int"}
        };

int main(const int argc, const char **argv)
{

  using namespace std;
  fstream in_file;

  in_file.open(argv[1], ios::in);
  // Generate a scanner
  IPL::Scanner scanner(in_file);
  // Generate a Parser, passing the scanner as an argument.
  // Remember %parse-param { Scanner  &scanner  }
  IPL::Parser parser(scanner);
  
  #ifdef YYDEBUG
   parser.set_debug_level(1);
  #endif 

  parser.parse();
  cout << "{\"globalST\":";
  gst.print();
  cout << ",";
  cout << "\"structs\":[";
  for(auto iter=list_struct.begin();iter!=list_struct.end();iter++){
    cout << "{\"name\":\"" << iter->first <<"\"," << endl;
    cout << "\"localST\":" << endl;
    iter->second->print();
    cout <<"}";
    if(next(iter,1)!=list_struct.end()) cout << "," << endl;
  }
  cout << "]," << endl;;
  cout << "\"functions\": [" << endl;
  for(auto iter=list_func.begin();iter!=list_func.end();iter++){
    cout << "{\"name\":\"" << iter->first <<"\"," << endl;
    cout << "\"localST\":" << endl;
    iter->second->print();
    cout << "," << endl;
    cout << "\"ast\":" << endl;
    ast[iter->first]->print(0);
    cout <<"}";
    if(next(iter,1)!=list_func.end()) cout << "," << endl;
  }
  cout << "]" << endl;
  cout << "}" << endl;
}

