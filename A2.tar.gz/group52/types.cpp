#include<iostream>
#include<string>
#include"types.hh"
using namespace std;

type_size::type_size(){}

type_size::type_size(string c1,int c2){
    this->type = c1;
    this->size = c2;
}

val_size::val_size(){}

val_size::val_size(string c1,int c2){
    this->val = c1;
    this->size = c2;
}

string find_pointer_type(string type){
    string new_type = "";
    bool mark=false;
    for(int i=0; type[i]!='\0'; i++){
        if(type[i]=='(' ||type[i]==')'){}
        else if(type[i]=='['){mark=true;}
        else if((type[i]=='0' || type[i]=='1' || type[i]=='2' || type[i]=='3' || type[i]=='4' || type[i]=='5' || type[i]=='6' || type[i]=='7' || type[i]=='8' || type[i]=='9')&&mark==true){}
        else if(type[i]==']'){new_type = new_type + "*";mark=false;}
        else {new_type = new_type+type[i];}
    }
    return new_type;
}

string array_to_pointer(string type){
    bool send = false;
    string new_type = "";
    for(int i=0; type[i]!='\0'; i++){
        if(type[i]=='('){}
	else if(type[i]==')'){send=true;}
        else {new_type = new_type+type[i];}
    }
    if(send) return new_type;
    bool present;
    int start,end;
    if(new_type.find('[')!=string::npos){
        present=true;
        start = (int)new_type.find('[');
        end = (int)new_type.find(']');
    }
    else present=false;
    if(present){
        new_type.erase(start,end-start+1);
        new_type.insert(start,"*");
    }
    return new_type;
}
