#include "symbtab.hh"
#include<iostream>
#include<vector>
#include<string>
using namespace std;

lst_entry::lst_entry(string c1,string c2,int c3,int c4,string c5){
    this->var_fun=c1;
    this->local_parameter=c2;
    this->size=c3;
    this->offset=c4;
    this->type=c5;
}

void localsymbtab::insert(string c1,string c2,string c3,int c4,int c5,string c6){
    this->entries[c1] = new lst_entry(c2,c3,c4,c5,c6);
}

void localsymbtab::print(){
    cout << "[";
    for(auto iter=this->entries.begin();iter!=this->entries.end();iter++){
        cout << "[";
        cout << "\"" << iter->first << "\","<< "\"" << iter->second->var_fun << "\","<< "\"" << iter->second->local_parameter << "\"," << to_string(iter->second->size) << "," << to_string(iter->second->offset) << ","<< "\"" << iter->second->type << "\"";
        cout << "]";
        if(next(iter,1)!=this->entries.end()) cout << "," << endl;
    }
    cout << "]";
}

gst_entry::gst_entry(string c1,string c2,int c3,int c4,string c5,localsymbtab* c6){
    this->var_fun_struct=c1;
    this->global=c2;
    this->size=c3;
    this->offset=c4;
    this->type=c5;
    this->st = c6;
}

globalsymbtab::globalsymbtab(){}

void globalsymbtab::insert(string c1,string c2,string c3,int c4,int c5,string c6,localsymbtab* c7){
    this->entries[c1] = new gst_entry(c2,c3,c4,c5,c6,c7);
}

void globalsymbtab::print(){
    cout << "[";
    for(auto iter=this->entries.begin();iter!=this->entries.end();iter++){
        cout << "[";
        if(iter->second->var_fun_struct=="struct") cout << "\"" << iter->first << "\","<< "\"" << iter->second->var_fun_struct << "\","<< "\"" << iter->second->global << "\"," << to_string(iter->second->size) << ", \"-\" ,"<< "\"-\"";
        else cout << "\"" << iter->first << "\","<< "\"" << iter->second->var_fun_struct << "\","<< "\"" << iter->second->global << "\"," << to_string(iter->second->size) << "," << to_string(iter->second->offset) << ","<< "\"" << iter->second->type << "\"";
        cout << "]";
        if(next(iter,1)!=this->entries.end()) cout << "," << endl;
    }
    cout << "]";
}