#include "ast.hh"
#include<iostream>
#include<vector>
#include<string>
using namespace std;

void empty_astnode::print(int blank){
    cout << "\"empty\"";
}

seq_astnode::seq_astnode(){
    this->astnode_type = SEQ;
}

seq_astnode::seq_astnode(statement_astnode* c1){
    this->astnode_type = SEQ;
    this->child1.push_back(c1);
}

void seq_astnode::add(statement_astnode* c1){
    this->child1.push_back(c1);
}

void seq_astnode::print(int blank){
    cout << "{\"seq\": [\n";
    for(int i=0;i<(long long int)child1.size();i++){
        child1[i]->print(0);
        if(i == (long long int) child1.size()-1){
            cout << "\n";
        } else {
            cout << ",\n";
        }
    }
    cout << "]}\n";
}

assignS_astnode::assignS_astnode(exp_astnode *c1, exp_astnode *c2){
    this->astnode_type = ASSIGNS;
    this->child1 = c1;
    this->child2 = c2;
}

void assignS_astnode::print(int blank){
    cout << "{\"assignS\": {";
    cout << "\"left\":";
    child1->print(0);
    cout << ",\n";
    cout << "\"right\":";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

return_astnode::return_astnode(exp_astnode *c1){
    this->astnode_type = RETURN;
    this->child1 = c1;
}

void return_astnode::print(int blank){
    cout << "{\"return\":";
    child1->print(0);
    cout << "}\n";
}

proccall_astnode::proccall_astnode(vector<exp_astnode*>* c1){
    this->astnode_type = PROCCALL;
    this->child1 = c1;
}

void proccall_astnode::print(int blank){
    cout << "{\"proccall\":{";
    cout << "\"fname\":";
    child1->back()->print(0);
    cout << ",";
    cout << "\"params\":[";
    if(child1->size()>1){
        for(int i=0;i<child1->size()-2;i++){
            child1->at(i)->print(0);
            cout << ",";
        }
        child1->at(child1->size()-2)->print(0);
    }
    cout << "]\n";
    cout << "}\n";
    cout << "}\n";
}

if_astnode::if_astnode(exp_astnode *c1, statement_astnode *c2, statement_astnode *c3){
    this->astnode_type = IF;
    this->child1 = c1;
    this->child2 = c2;
    this->child3 = c3;
}

void if_astnode::print(int blank){
    cout << "{\"if\": {\n";
    cout << "\"cond\":";
    child1->print(0);
    cout << ",\n";
    cout << "\"then\":";
    child2->print(0);
    cout << ",\n";
    cout << "\"else\":";
    child3->print(0);
    cout << "}\n";
    cout << "}\n";
}

while_astnode::while_astnode(exp_astnode *c1, statement_astnode *c2){
    this->astnode_type = WHILE;
    this->child1 = c1;
    this->child2 = c2;
}

void while_astnode::print(int blank){
    cout << "{\"while\": {\n";
    cout << "\"cond\":";
    child1->print(0);
    cout << ",\n";
    cout << "\"stmt\":";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

for_astnode::for_astnode(exp_astnode *c1,exp_astnode *c2,exp_astnode *c3,statement_astnode *c4){
    this->astnode_type = FOR;
    this->child1 = c1;
    this->child2 = c2;
    this->child3 = c3;
    this->child4 = c4;
}

void for_astnode::print(int blank){
    cout << "{\"for\": {\n";
    cout << "\"init\": ";
    child1->print(0);
    cout << ",\n";
    cout << "\"guard\": ";
    child2->print(0);
    cout << ",\n";
    cout << "\"step\": ";
    child3->print(0);
    cout << ",\n";
    cout << "\"body\": ";
    child4->print(0);
    cout << "}\n";
    cout << "}\n";
}

op_binary_astnode::op_binary_astnode(string c1, exp_astnode *c2, exp_astnode *c3){
    this->astnode_type = OP_BINARY;
    this->child1 = c1;
    this->child2 = c2;
    this->child3 = c3;
}

void op_binary_astnode::print(int blank){
    cout << "{\"op_binary\": {\n";
    cout << "\"op\": \"" << child1 << "\",\n";
    cout << "\"left\":";
    child2->print(0);
    cout << ",\n";
    cout << "\"right\":";
    child3->print(0);
    cout << "}\n";
    cout << "}\n";
}

op_unary_astnode::op_unary_astnode(string c1, exp_astnode *c2){
    if(c1=="UMINUS") this->astnode_type = OP_UNARY_UMINUS;
    else if(c1=="NOT") this->astnode_type = OP_UNARY_NOT;
    else if(c1=="DEREF") this->astnode_type = OP_UNARY_DEREF;
    else if(c1=="ADDRESS") this->astnode_type = OP_UNARY_ADDRESS;
    else if(c1=="PP") this->astnode_type = OP_UNARY_PP;
    this->child1 = c1;
    this->child2 = c2;
}

void op_unary_astnode::print(int blank){
    cout << "{\"op_unary\": {\n";
    cout << "\"op\": \"" << child1 << "\",\n";
    cout << "\"child\": ";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

assignE_astnode::assignE_astnode(exp_astnode *c1, exp_astnode *c2){
    this->astnode_type = ASSIGNE;
    this->child1 = c1 ;
    this->child2 = c2 ;
}

void assignE_astnode::print(int blank){
    cout << "{\"assignE\": {\n";
    cout << "\"left\": ";
    child1->print(0);
    cout << ",\n";
    cout << "\"right\": ";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

funcall_astnode::funcall_astnode(vector<exp_astnode*>* c1){
    this->astnode_type = FUNCALL;
    this->child1 = c1;
}

void funcall_astnode::print(int blank){
    cout << "{\"funcall\":{";
    cout << "\"fname\":";
    child1->back()->print(0);
    cout << ",";
    cout << "\"params\":[";
    if(child1->size()>1){
        for(int i=0;i<child1->size()-2;i++){
            child1->at(i)->print(0);
            cout << ",";
        }
        child1->at(child1->size()-2)->print(0);
    }
    cout << "]\n";
    cout << "}\n";
    cout << "}\n";
}

floatconst_astnode::floatconst_astnode(float c1){
    if(c1==0) this->astnode_type = FLOATCONST0;
    else this->astnode_type = FLOATCONST;
    this->child1 = c1;
}

void floatconst_astnode::print(int blank){
    cout << "{\"floatconst\": " << child1 << "}\n";
}

intconst_astnode::intconst_astnode(int c1){
    if(c1==0) this->astnode_type = INTCONST0;
    else this->astnode_type = INTCONST;
    this->child1 = c1;
}

void intconst_astnode::print(int blank){
    cout << "{\"intconst\": " << child1 << "}\n";
}

string_astnode::string_astnode(string c1){
    this->astnode_type = STRINGCONST;
    this->child1 = c1;
}

void string_astnode::print(int blank){
    cout << "{\"stringconst\": " << child1 << "}\n";
}

identifier_astnode::identifier_astnode(string c1){
    this->astnode_type = IDENTIFIER;
    this->child1=c1;
}

void identifier_astnode::print(int blank){
    cout << "{\"identifier\": \"" << child1 << "\"}\n";
}

member_astnode::member_astnode(exp_astnode *c1, identifier_astnode *c2){
    this->astnode_type = MEMBER;
    this->child1 = c1;
    this->child2 = c2;
}

void member_astnode::print(int blank){
    cout << "{\"member\": {\n";
    cout << "\"struct\": ";
    child1->print(0);
    cout << ",\n";
    cout << "\"field\": ";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

arrow_astnode::arrow_astnode(exp_astnode *c1, identifier_astnode *c2){
    this->astnode_type = ARROW;
    this->child1 = c1;
    this->child2 = c2;
}

void arrow_astnode::print(int blank){
    cout << "{\"arrow\": {\n";
    cout << "\"pointer\": ";
    child1->print(0);
    cout << ",\n";
    cout << "\"field\": ";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}

arrayref_astnode::arrayref_astnode(exp_astnode *c1, exp_astnode *c2){
    this->astnode_type = ARRAYREF;
    this->child1 = c1;
    this->child2 = c2;
}

void arrayref_astnode::print(int blank){
    cout << "{\"arrayref\": {\n";
    cout << "\"array\": ";
    child1->print(0);
    cout << ",\n";
    cout << "\"index\": ";
    child2->print(0);
    cout << "}\n";
    cout << "}\n";
}