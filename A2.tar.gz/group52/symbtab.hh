#include<iostream>
#include<vector>
#include<string>
#include <map>
using namespace std;

class lst_entry{
    public:
        string var_fun;
        string local_parameter;
        int size;
        int offset;
        string type;
        lst_entry(string c1,string c2,int c3,int c4,string c5);
};

class localsymbtab{
    public:
        string func_name;
        map<string,lst_entry*> entries;
        vector<string> param_types;
        void insert(string c1,string c2,string c3,int c4,int c5,string c6);
        void print();
};

class gst_entry{
    public:
        string var_fun_struct;
        string global;
        int size;
        int offset;
        string type;
        localsymbtab* st;
        gst_entry(string c1,string c2,int c3,int c4,string c5,localsymbtab* c6);
};

class globalsymbtab{
    public:
        map<string,gst_entry*> entries;
        globalsymbtab();
        void insert(string c1,string c2,string c3,int c4,int c5,string c6,localsymbtab* c7);
        void print();
};